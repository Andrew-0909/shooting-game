let bullettrain = [];
let targettrain = [];
let player;
let score = 0;
let missed = 0;
let gameOver = false;
function setup() {
  createCanvas(600, 400);
 player = new Player();
  for(let i = 0; i <3; i++){
    targettrain.push(new Target(random(0, 600), random(-200,0), random(1, 5)));
    
}
}


function draw(){
  background(0);
  if(!gameOver){
   player.display();
  for(let i = bullettrain.length-1; i >= 0; i--){
    bullettrain[i].move();
    bullettrain[i].display();
     if(bullettrain[i].y<0){
    bullettrain.splice(i, 1);
  }
  } 
    
for(let i = targettrain.length-1; i >= 0; i--){
    targettrain[i].move();
    targettrain[i].display();
  for(let j = bullettrain.length-1; j>=0; j--){
    if(targettrain[i].isHit(bullettrain[j])){
      targettrain.splice(i, 1);
      bullettrain.splice(j, 1);
      score++;
      targettrain.push(new Target(random(0,600),0,random(1,5)));
      break;
    }
  }
  }
  fill(255, 255, 255);
  textSize(10);
   text(`Score: ${score}`, 10, 20);
     text(`missed: ${missed}`, 10, 40);
    if(missed > 15){
       gameOver = true;
       }
} else{
  fill(255, 255, 255);
  textSize(36);
  textAlign(CENTER,CENTER);
  text("Game Over",300,200);
  text(`Final Score: ${score}`, 300, 250);
}
  
}
function keyPressed(){
  if(key ===' '){
    bullettrain.push(new Bullet(player.x+25, player.y));
  }
}
class Player{
  constructor(){
   this.x = 275
   this.y = 350
   this.width = 50
   this.height = 30
    this.speed = 10
  }
  display(){
    fill(255, 0, 0)
  rect(this.x, this.y, this.width, this.height)
    if(keyIsDown(LEFT_ARROW)&& this.x > 0){
      this.x -= this.speed
    }
    if(keyIsDown(RIGHT_ARROW)&& this.x < 550){
      this.x += this.speed
  }
  }
}
class Bullet{
  constructor(x,y){
    this.x = x;
    this.y = y;
    this.size = 10;
    this.speed = 9;
    
  }
  move(){
    this.y -= this.speed
  }
  display(){
    fill(0, 0, 255)
    circle(this.x, this.y, this.size)
  }
}
class Target{
  constructor(x,y,speed){
    this.x = x;
    this.y = y;
    this.size = 50;
    this.speed = speed;
  }
  move(){
    this.y += this.speed;
    if(this.y > 400){
    this.y = 0;
      this.x = random(0, 600);
      missed += 1;
  }
}
  display(){
    fill(0, 255, 0);
    circle(this.x, this.y, this.size);
  }
  isHit(bullet){
    let distance = dist(this.x, this.y, bullet.x, bullet.y);
    return distance < this.size/2 + bullet.size/2;
  }
}